package com.manga.translate.settings

import androidx.core.graphics.ColorUtils
import com.manga.translate.R
import com.manga.translate.model.FloatingBallGestureAction
import com.manga.translate.model.OcrApiFormat
import com.manga.translate.model.ThinkingLength
import com.manga.translate.rendering.BubbleFont

data class OcrApiSettings(
    val useLocalOcr: Boolean,
    val apiUrl: String,
    val apiKey: String,
    val modelName: String,
    val timeoutSeconds: Int,
    val apiOcrConcurrencyLimit: Int,
    val localOcrConcurrencyLimit: Int,
    val ocrApiFormat: OcrApiFormat
) {
    fun isValid(): Boolean {
        return useLocalOcr || (apiUrl.isNotBlank() && modelName.isNotBlank())
    }
}

data class FloatingTranslateApiSettings(
    val apiUrl: String,
    val apiKey: String,
    val modelName: String,
    val timeoutSeconds: Int,
    val useVlDirectTranslate: Boolean,
    val ocrConcurrencyLimit: Int,
    val aiApiConcurrencyLimit: Int,
    val proofreadingModeEnabled: Boolean,
    val autoCloseOnScreenChangeEnabled: Boolean,
    val singleTapAction: FloatingBallGestureAction,
    val doubleTapAction: FloatingBallGestureAction,
    val longPressAction: FloatingBallGestureAction,
    val tripleTapAction: FloatingBallGestureAction,
    val detectionTopInsetPercent: Int,
    val detectionBottomInsetPercent: Int
)

data class LlmParameterSettings(
    val temperature: Double?,
    val topP: Double?,
    val topK: Int?,
    val maxOutputTokens: Int?,
    val enableThinking: Boolean,
    val thinkingLength: ThinkingLength,
    val frequencyPenalty: Double?,
    val presencePenalty: Double?
)

data class CustomRequestParameter(
    val key: String,
    val value: String,
    val enabled: Boolean
)

data class AiProviderProfile(
    val name: String,
    val mainSettings: ApiSettings,
    val apiTimeoutSeconds: Int,
    val apiRetryCount: Int,
    val maxConcurrency: Int,
    val ocrSettings: OcrApiSettings,
    val floatingTranslateSettings: FloatingTranslateApiSettings,
    val llmParameters: LlmParameterSettings,
    val customRequestParameters: List<CustomRequestParameter>
)

data class AiProviderProfilesState(
    val activeProfileName: String?,
    val profiles: List<AiProviderProfile>
)

data class CustomThemeColors(
    val background: Int,
    val surface: Int,
    val surfaceAlt: Int,
    val accent: Int,
    val accentContent: Int,
    val foreground: Int,
    val mutedForeground: Int,
    val outline: Int,
    val buttonFill: Int,
    val buttonPressed: Int,
    val buttonText: Int,
    val heroStart: Int,
    val heroEnd: Int
) {
    companion object {
        val DEFAULT = CustomThemeColors(
            background = 0xFF101820.toInt(),
            surface = 0xFF182432.toInt(),
            surfaceAlt = 0xFF1E2D3D.toInt(),
            accent = 0xFFF0A040.toInt(),
            accentContent = 0xFF101820.toInt(),
            foreground = 0xFFE8EAED.toInt(),
            mutedForeground = 0xFF9AA0A6.toInt(),
            outline = 0xFF3C4043.toInt(),
            buttonFill = 0xFFF0A040.toInt(),
            buttonPressed = 0xFFD08830.toInt(),
            buttonText = 0xFF101820.toInt(),
            heroStart = 0xFF101820.toInt(),
            heroEnd = 0xFF1E2D3D.toInt()
        )

        fun fromBaseColors(background: Int, surface: Int, accent: Int): CustomThemeColors {
            val isDark = ColorUtils.calculateLuminance(surface) < 0.5
            val surfaceAlt = shiftColor(surface, if (isDark) 0.08f else -0.05f)
            val foreground = ensureContrast(
                base = if (isDark) 0xFFE8EAED.toInt() else 0xFF1A1A1A.toInt(),
                against = surface,
                minContrast = 4.5f
            )
            val accentContent = ensureContrast(
                base = if (ColorUtils.calculateLuminance(accent) > 0.5) 0xFF1A1A1A.toInt() else 0xFFFFFFFF.toInt(),
                against = accent,
                minContrast = 4.5f
            )
            val mutedForeground = shiftColor(foreground, if (isDark) -0.3f else 0.3f)
            val outline = if (isDark) {
                blendColors(surface, foreground, 0.2f)
            } else {
                blendColors(surface, foreground, 0.15f)
            }
            val buttonFill = accent
            val buttonPressed = shiftColor(accent, if (isDark) -0.12f else -0.1f)
            val buttonText = accentContent
            val heroStart = background
            val heroEnd = surfaceAlt
            return CustomThemeColors(
                background = background,
                surface = surface,
                surfaceAlt = surfaceAlt,
                accent = accent,
                accentContent = accentContent,
                foreground = foreground,
                mutedForeground = mutedForeground,
                outline = outline,
                buttonFill = buttonFill,
                buttonPressed = buttonPressed,
                buttonText = buttonText,
                heroStart = heroStart,
                heroEnd = heroEnd
            )
        }

        private fun ensureContrast(base: Int, against: Int, minContrast: Float): Int {
            var candidate = base
            val againstLum = ColorUtils.calculateLuminance(against)
            val lighten = againstLum < 0.5f
            var hsv = FloatArray(3)
            ColorUtils.colorToHSV(candidate, hsv)
            var attempts = 0
            while (ColorUtils.calculateContrast(candidate, against) < minContrast && attempts < 30) {
                hsv[2] = if (lighten) {
                    (hsv[2] + 0.05f).coerceAtMost(1f)
                } else {
                    (hsv[2] - 0.05f).coerceAtLeast(0f)
                }
                candidate = ColorUtils.HSVToColor(hsv)
                attempts++
            }
            return candidate
        }

        private fun shiftColor(color: Int, amount: Float): Int {
            val hsv = FloatArray(3)
            ColorUtils.colorToHSV(color, hsv)
            hsv[2] = (hsv[2] + amount).coerceIn(0f, 1f)
            return ColorUtils.HSVToColor(ColorUtils.alpha(color), hsv)
        }

        private fun blendColors(color1: Int, color2: Int, ratio: Float): Int {
            return ColorUtils.blendARGB(color1, color2, ratio)
        }
    }
}

data class BubbleFontSettings(
    val font: BubbleFont,
    val customFontFileName: String,
    val isBold: Boolean,
    val fontSizeScalePercent: Int
)

data class NormalBubbleRenderSettings(
    val shrinkPercent: Int,
    val opacityPercent: Int,
    val freeBubbleShrinkPercent: Int,
    val freeBubbleOpacityPercent: Int,
    val useHorizontalText: Boolean,
    val autoAdaptBubbleColor: Boolean,
    val autoAdaptFreeBubbleColor: Boolean,
    val textRemovalMethod: TextRemovalMethod,
    val font: BubbleFont = BubbleFont.SYSTEM_DEFAULT,
    val customFontUrl: String = "",
    val customFontFileName: String = "",
    val isBold: Boolean = false,
    val fontSizeScalePercent: Int = SettingsStore.DEFAULT_BUBBLE_FONT_SIZE_SCALE_PERCENT
)

enum class FloatingBubbleShape(
    val prefValue: String,
    val labelRes: Int
) {
    RECTANGLE("rectangle", R.string.floating_bubble_shape_rectangle),
    INSCRIBED_ELLIPSE("inscribed_ellipse", R.string.floating_bubble_shape_inscribed_ellipse);

    companion object {
        fun fromPref(value: String?): FloatingBubbleShape {
            return entries.firstOrNull { it.prefValue == value } ?: RECTANGLE
        }
    }
}

data class FloatingBubbleRenderSettings(
    val sizeAdjustPercent: Int,
    val opacityPercent: Int,
    val shape: FloatingBubbleShape,
    val useHorizontalText: Boolean,
    val autoAdaptBubbleColor: Boolean,
    val font: BubbleFont = BubbleFont.SYSTEM_DEFAULT,
    val customFontUrl: String = "",
    val customFontFileName: String = "",
    val isBold: Boolean = false,
    val fontSizeScalePercent: Int = SettingsStore.DEFAULT_BUBBLE_FONT_SIZE_SCALE_PERCENT,
    val textRemovalMethod: TextRemovalMethod = TextRemovalMethod.SOLID_FILL
)
