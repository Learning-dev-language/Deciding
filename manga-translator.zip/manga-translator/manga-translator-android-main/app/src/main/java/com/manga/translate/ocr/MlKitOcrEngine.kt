package com.manga.translate.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.RectF
import androidx.annotation.WorkerThread
import com.google.mlkit.vision.common.InputImage
import com.manga.translate.platform.AppLogger
import com.manga.translate.settings.OcrScript
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

internal class MlKitOcrEngine(
    context: Context,
    private val script: OcrScript
) : OcrEngine, AutoCloseable {
    private val appContext = context.applicationContext

    internal val isEngineClosed: Boolean get() = isClosed.get()

    // Lifecycle state tracking - thread-safe for close() and recognize() coordination
    private val isClosed = AtomicBoolean(false)
    private val activeOperations = AtomicInteger(0)

    private val textRecognizer by lazy {
        try {
            val recognizer = when (script) {
                OcrScript.LATIN -> {
                    androidx.mlkit.textrecognition.TextRecognizer.Builder().build()
                }
                OcrScript.CHINESE -> {
                    androidx.mlkit.textrecognition.chinese.ChineseTextRecognizer.Builder().build()
                }
                OcrScript.JAPANESE -> {
                    androidx.mlkit.textrecognition.japanese.JapaneseTextRecognizer.Builder().build()
                }
                OcrScript.KOREAN -> {
                    androidx.mlkit.textrecognition.korean.KoreanTextRecognizer.Builder().build()
                }
                OcrScript.DEVANAGARI -> {
                    androidx.mlkit.textrecognition.devanagari.DevanagariTextRecognizer.Builder().build()
                }
                OcrScript.AUTO -> {
                    androidx.mlkit.textrecognition.TextRecognizer.Builder().build()
                }
            }
            recognizer
        } catch (e: Exception) {
            AppLogger.log(LOG_TAG, "Failed to initialize ML Kit text recognizer for script: ", e)
            null
        }
    }

    private companion object {
        private const val LOG_TAG = "MlKitOcrEngine"
    }

    @WorkerThread
    private fun recognizeFromBackground(bitmap: Bitmap): String {
        val recognizer = textRecognizer ?: return ""
        return runBlocking(kotlinx.coroutines.Dispatchers.Default) {
            if (isClosed.get()) return@runBlocking ""
            activeOperations.incrementAndGet()
            try {
                suspendCancellableCoroutine { cont ->
                val task = recognizer.process(
                    InputImage.fromBitmap(bitmap, 0)
                )
                task.addOnSuccessListener { result ->
                    cont.resume(result.text)
                }
                task.addOnFailureListener { e ->
                    cont.resumeWithException(e)
                }
                    cont.invokeOnCancellation { task.cancel() }
                }
            } finally {
                activeOperations.decrementAndGet()
            }
        }
    }

    override fun recognize(bitmap: Bitmap): String {
        if (isClosed.get()) return ""
        try {
            return recognizeFromBackground(bitmap)
        } catch (e: Exception) {
            AppLogger.log(LOG_TAG, "OCR recognition failed for script: ", e)
            return ""
        }
    }

    override fun recognizeWithScore(bitmap: Bitmap, rect: RectF?): OcrEngine.OcrEngineResult {
        return recognize(bitmap).let { text ->
            OcrEngine.OcrEngineResult(text, if (text.isNotBlank()) 0.95f else 0f)
        }
    }

    override fun close() {
        isClosed.set(true)
        // Wait for active recognition operations to complete
        while (activeOperations.get() > 0) {
            Thread.sleep(10)
        }
        try {
            @Suppress("UNNECESSARY_SAFE_CALL")
            (textRecognizer as? AutoCloseable)?.close()
        } catch (e: Exception) {
            AppLogger.log(LOG_TAG, "Failed to close ML Kit TextRecognizer", e)
        }
    }
}
